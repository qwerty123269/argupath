(()=>{
'use strict';
const cases = {
 primary: {
  genre:['Story writing','記敘文'],title:['A small act at the gate','校門口的小事'],skill:['Show a feeling through an action.','用一個動作寫出心情。'],
  brief:['It starts raining at the school gate. Tell a friend what someone did to help and how the moment felt.','放學時，校門口下起雨來。把有人伸出援手的那一刻寫給朋友看。'],
  material:['You have one umbrella. A younger child is holding a paper bird. Rain has begun to spot its wings.','你手中只有一把傘。身旁的小朋友捧着一隻紙鳥，雨點已經落到翅膀上。'],
  draft:['Rain tapped on my umbrella. A little boy stood beside me with a paper bird. I helped him. We walked through the gate together.','雨點滴答滴答地打在我的傘上。一個小男孩捧着紙鳥，站在我旁邊。我幫了他。我們一起走過校門。'],
  line:['I helped him.','我幫了他。'],focus:['A visible action','看得見的動作'],question:['What could a reader see your hands doing?','讀者能看見你的手做了甚麼？'],
  alternative:['The boy’s reaction','對方的反應'],other:['What did the boy do when the umbrella reached him?','雨傘移到他頭上時，小男孩做了甚麼？'],
  fix:['I tilted my umbrella until both paper wings were dry beneath it.','我把傘往他那邊斜了斜，兩隻紙翅膀都躲進傘下。'],why:['The tilt of the umbrella shows how I helped.','把傘往旁邊移這個動作，讓人看得出我是怎樣幫忙的。'],
  fix2:['When I held the umbrella over him, he unfolded one damp wing and smiled.','我把傘移到他頭上。他攤開一隻濕了的紙翅膀，笑了。'],why2:['His smile lets the reader see how he felt.','他攤開翅膀時笑了，讀者就知道他的心情。']
 },
 narrative: {
  genre:['Narrative','記敘文'],title:['The missed entrance','錯過的入場時刻'],skill:['Let one turning point change the story.','用一個轉折帶出人物的改變。'],
  brief:['Write a scene for the school magazine about a missed cue at a rehearsal. Stay close to the narrator’s point of view.','為校刊寫一幕排練時錯過出場提示的經歷，從敘事者的角度描寫現場。'],
  material:['A page sticks to the music stand. The drummer holds the beat. The narrator can hear the pause but cannot know what the audience thinks.','一頁樂譜黏在譜架上。鼓手仍然打着拍子。敘事者聽得出自己慢了，卻無法知道觀眾在想甚麼。'],
  draft:['My page stuck to the stand. I missed my entrance. Everyone thought I had ruined the song. Then I started playing again.','樂譜黏在譜架上。我錯過了進拍的時機。所有人都覺得我把曲子毀了。接着，我又奏了下去。'],
  line:['Everyone thought I had ruined the song.','所有人都覺得我把曲子毀了。'],focus:['Point of view','敘事視角'],question:['What can the narrator actually hear or see in that pause?','在那一刻，敘事者究竟聽見或看見了甚麼？'],
  alternative:['The turning point','情節轉折'],other:['Which small signal gives the narrator a way back into the music?','哪個細微信號讓敘事者找到重新進拍的時機？'],
  fix:['For one bar I heard only the drummer, tapping the beat I had lost.','整整一小節，我只聽見鼓手敲着我跟丟了的拍子。'],why:['The sound is within the narrator’s experience. It lets readers infer the embarrassment.','鼓聲是敘事者能聽見的，讀者可以從這一小節的空白體會他的窘迫。'],
  fix2:['The drummer lifted one stick, and on the next beat I found my place.','鼓手舉起一根鼓棒，下一拍，我終於找回了自己的位置。'],why2:['The drummer’s cue explains how the scene turns.','鼓手的提示交代了事情怎樣出現轉機。']
 },
 explain: {
  genre:['Expository','說明文'],title:['Where did the droplets come from?','杯外的水珠從哪裏來？'],skill:['Link an observation to its cause.','從觀察出發，把原因說清楚。'],
  brief:['Write a display label for a science fair. Explain why droplets appear on the outside of a cold cup.','為科學展寫一張說明卡，解釋冷杯外壁為甚麼會出現水珠。'],
  material:['Two dry, sealed cups stand side by side. One contains ice water, the other room-temperature water. After five minutes, droplets are visible only on the cold cup.','兩個擦乾、密封的杯子並排擺放，一杯裝冰水，一杯裝室溫水。五分鐘後，只有冰杯的外壁出現水珠。'],
  draft:['Both cups were dry at the start. After five minutes, only the cold cup had droplets outside. The cold made the water appear.','起初，兩個杯子的外壁都是乾的。五分鐘後，只有冰杯外面出現了水珠。因為冷，所以有水。'],
  line:['The cold made the water appear.','因為冷，所以有水。'],focus:['The mechanism','形成過程'],question:['Where does the water come from, and what changes when the air cools?','這些水原先在哪裏？空氣遇冷時，水的狀態有甚麼改變？'],
  alternative:['A useful comparison','對照觀察'],other:['What observation helps distinguish condensation from a leak?','哪項對照觀察有助於區分凝結和漏水？'],
  fix:['Water vapour in the surrounding air cooled at the cold surface and condensed into droplets.','空氣中的水蒸氣遇到冰冷的杯壁，凝結成一顆顆小水珠。'],why:['The revision identifies the source of the water and the change from gas to liquid.','改寫交代了水的來源，也說清楚它從氣體變成液體的過程。'],
  fix2:['Both cups were sealed, yet only the cold one grew droplets: moisture in the air condensed on its surface.','兩杯都密封着，卻只有冰杯外壁出現水珠，這與空氣中的水蒸氣在冷表面凝結的解釋相符。'],why2:['The comparison connects the observation to an explanation.','兩杯的對照讓觀察結果和解釋連得起來。']
 },
 argue: {
  genre:['Argumentative','議論文'],title:['A quiet lunch space?','午飯時段要設安靜區嗎？'],skill:['Match a recommendation to its evidence.','讓建議的範圍符合手上的證據。'],
  brief:['Write to the student council about a proposal for a quiet lunch room. Make a recommendation that the council could act on.','學生會正考慮午飯時段開放安靜室。寫一段意見，提出一項可以落實的建議。'],
  material:['In a fictional school poll, 18 of 30 volunteers wanted a quiet option. Others worried about losing space to eat with friends. No whole-school survey has been held.','在這個模擬校園情境中，30 名自願受訪者有 18 人希望多一個安靜的選擇，亦有人擔心和朋友吃飯的地方會減少。學校尚未作全校調查。'],
  draft:['Eighteen of the thirty volunteers wanted a quiet lunch space. Everyone wants silent lunches. The council meets on Friday to discuss the proposal.','30 名自願受訪者中，有 18 人希望有安靜的午飯空間。人人都想安安靜靜吃午飯。學生會將在星期五討論這項建議。'],
  line:['Everyone wants silent lunches.','人人都想安安靜靜吃午飯。'],focus:['Scope of evidence','證據的範圍'],question:['Whose views are represented by these thirty responses?','這 30 份意見可以代表哪些人？'],
  alternative:['A competing need','另一方的需要'],other:['How could a trial protect the space students use to talk with friends?','怎樣試行，才能兼顧想和朋友聊天的同學？'],
  fix:['The poll suggests some students would use an optional quiet room, so a short trial is worth considering.','這次調查顯示，部分學生願意使用安靜室，值得先試行一段短時間，讓同學自行選擇。'],why:['Volunteers cannot speak for everyone. A trial fits the limited evidence.','自願受訪者無法代表全校；先試行，較切合目前證據的範圍。'],
  fix2:['A separate room could give some students a quieter lunch while leaving the dining hall open for conversation.','另設一間安靜室，既照顧部分同學的需要，也保留飯堂作為聊天的地方。'],why2:['The proposal addresses the concern about losing social space.','這項建議回應了同學擔心失去交流空間的顧慮。']
 }
};

const root=document.querySelector('#paths');
const tracks={primary:['primary'],secondary:['narrative','explain','argue'],university:['research']};
const levels={primary:['Primary school','小學'],secondary:['Secondary school','中學'],university:['University','大學及研究生']};
const sub={primary:['A moment in a story','寫出故事的一刻'],secondary:['Three ways to write','三種文體練習'],university:['Research discussion','學術討論段落']};
const academic={genre:['Academic writing','學術寫作'],title:['Social media and anxiety','社交媒體與焦慮'],skill:['Trace a claim to its sources, weigh feedback and revise a research discussion.','追查主張的證據，判斷回饋是否合理，再修訂討論段落。']};
const K='argupath.routes.1';let saved={},tempFail=false;
try{saved=JSON.parse(localStorage.getItem(K)||'{}')||{}}catch{tempFail=true}
let lang=saved.lang==='zh'?1:0,level=Object.hasOwn(levels,saved.level)?saved.level:'primary',route=tracks[level].includes(saved.route)?saved.route:tracks[level][0],page='home';
const l=(a,b)=>lang?b:a, tr=a=>a[lang], esc=a=>String(a??'').replace(/[&<>"']/g,k=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[k]));
const caseKey=()=>route+'-'+lang;
const emptyRun=()=>({stage:0,draft:'',index:0,lens:0,fix:'',why:'',sample:false});
const row=()=>{saved.work??={};return saved.work[caseKey()]??=emptyRun()};
const hasWork=r=>!!r&&(r.stage>0||!!r.draft||!!r.record);
function pastRuns(){saved.past??={};return saved.past[caseKey()]??=[]}
function archiveRun(){
 const r=row();
 if(hasWork(r))pastRuns().unshift({...r,savedAt:Date.now()});
}
function freshRun(){archiveRun();saved.work[caseKey()]=emptyRun()}
function restoreRun(i){
 const list=pastRuns();
 if(!Number.isInteger(i)||i<0||i>=list.length)return;
 const [selectedRun]=list.splice(i,1);
 archiveRun();saved.work[caseKey()]=selectedRun;
}
const store=()=>{saved.lang=lang?'zh':'en';saved.level=level;saved.route=route;try{localStorage.setItem(K,JSON.stringify(saved))}catch{tempFail=true}};
const status=()=>tempFail?l('Storage unavailable. Download your record before closing.','無法在裝置儲存。關閉前請下載記錄。'):l('Work is saved in this browser. Each language has its own writing record.','進度會儲存在這個瀏覽器；兩種語言各自保留寫作記錄。');
const tag=(s)=>'<span class="step-tag">→ '+esc(s)+'</span>';
const step=n=>tag(l('Step ','步驟 ')+n);
const btn=(s,a,cls='',extra='')=>'<button type="button" data-path="'+esc(a)+'" class="'+cls+'" '+extra+'>'+esc(s)+'</button>';
const languages=()=>'<div class="route-languages" role="group" aria-label="Language / 語言">'+['English','繁體中文'].map((label,i)=>btn(label,'language:'+i,'','aria-pressed="'+(i===lang)+'" lang="'+(i?'zh-Hant':'en')+'"')).join('')+'</div>';
const nav=()=>'<header class="path-nav"><button class="wordmark" data-path="home"><span class="mark" aria-hidden="true">A</span>ArguPath</button>'+languages()+'</header>';
const sample=()=>route==='research'?academic:cases[route];
function overviewCards(){
 const c=sample(),research=route==='research';
 const cards=[
 [l('Writing task','寫作任務'),tr(c.title),research?l('Read a prepared research discussion alongside six teaching sources.','對照六份教學用研究材料，閱讀一篇討論稿。'):tr(c.brief)],
 [l('Review question','檢查問題'),research?l('How far does the evidence reach?','這些證據能支持多強的結論？'):tr(c.focus),research?l('Inspect the study design, comparison group and uncertainty before judging a claim.','先看研究設計、對照組與結果的不確定性，再判斷主張。'):tr(c.question)],
 [l('Revision record','修訂記錄'),l('See what changed and why','比較改寫，讀懂理由'),research?l('Review feedback decisions and saved versions, then try the reasoning on a new topic.','回顧批註判斷與已儲存的版本，再把推理應用到新題目。'):l('Compare the two drafts and download the sentence and reason you chose.','對照初稿與修訂稿，下載改寫內容及你寫下的理由。')]
 ];
 return '<section class="path-features"><h2>'+l('Inside this workshop','這項練習有甚麼？')+'</h2><div class="feature-grid">'+cards.map(([label,title,detail])=>'<details><summary><small>'+esc(label)+'</small><strong>'+esc(title)+'</strong></summary><p>'+esc(detail)+'</p></details>').join('')+'</div></section>'
}
const home=()=>nav()+'<main><header class="path-intro"><h1>'+l('Choose a writing task','選一個寫作任務')+'</h1><p>'+l('Choose your level and genre. Each workshop takes you from a first draft to a revision you can explain.','先選學習階段，再選文體。從一段草稿開始，一步步改寫，說出修改的理由。')+'</p></header><div class="panel-grid"><section class="levels">'+step(1)+'<h2>'+l('Learning level','學習階段')+'</h2><div class="level-list">'+Object.keys(levels).map((k,i)=>'<button class="lv" data-path="level:'+k+'" aria-pressed="'+(k===level)+'"><span class="level-icon" aria-hidden="true">'+['✎','▤','§'][i]+'</span><span><strong>'+tr(levels[k])+'</strong><small>'+tr(sub[k])+(k==='university'?l(' (main demo)','（主要示範）'):'')+'</small></span><span class="tick" aria-hidden="true">'+(k===level?'✓':'›')+'</span></button>').join('')+'</div></section><section class="genre-panel">'+step(2)+'<h2>'+l('Writing genre','寫作文體')+'</h2><div class="tabs">'+tracks[level].map(k=>btn(tr((cases[k]||academic).genre),'genre:'+k,'','aria-pressed="'+(k===route)+'"')).join('')+'</div>'+(route==='research'?'<p class="demo-caption">'+l('(Main demo: academic writing coaching)','（主要 Demo 展示板塊：學術寫作輔導）')+'</p>':'')+'<div class="folio"><span class="label">'+l('YOUR WRITING TASK','你的寫作任務')+'</span><h3>'+tr(sample().title)+'</h3><p>'+tr(sample().skill)+'</p></div><div class="actions">'+step(3)+launchButtons()+'</div></section></div>'+overviewCards()+'</main>';
function launchButtons(){
 if(route==='research'){
  const fresh=btn(l('Start academic demo · Step 1 →','從第 1 步開始學術示範 →'),'start','primary-btn');
  return fresh+(window.apAcademic?.hasProgress?.()?btn(l('Resume academic work','繼續上次學術練習'),'resume','minor'):'');
 }
 const live=row(),older=pastRuns(),last=hasWork(live)?live:older[0];
 let buttons=btn(l('Start from Step 1 →','從第 1 步開始 →'),'start','primary-btn');
 if(last)buttons+=btn(l('Resume · ','繼續上次練習 · ')+(last.stage+1)+' / '+tr([...stages,['Record','記錄']][last.stage]),'resume','minor');
 const first=hasWork(live)?0:1;
 if(older.length>first)buttons+='<details class="case-history"><summary>'+l('Earlier attempts for this case','這個案例的過往練習')+'</summary>'+older.slice(first).map((r,j)=>btn(l('Open · ','開啟 · ')+tr([...stages,['Record','記錄']][r.stage])+' · '+new Date(r.savedAt).toLocaleString(lang?'zh-HK':'en-GB'),'oldrun:'+(j+first),'micro')).join('')+'</details>';
 return buttons;
}
const stages=[['Read','讀題'],['Draft','起草'],['Review','檢查'],['Revise','修訂']];
function parts(s){return Array.from(s.matchAll(/[^.!?。！？\n]+(?:[.!?。！？]+|(?=\n|$))|[.!?。！？]+/gu)).map(m=>({text:m[0].trim(),pos:m.index+m[0].search(/\S/u)})).filter(x=>x.text)}
function selected(r){return parts(r.draft)[r.index]||{text:r.draft,pos:0}}
function revised(r){const x=selected(r);return r.draft.slice(0,x.pos)+r.fix.trim()+r.draft.slice(x.pos+x.text.length)}
const field=(id,label,value,rows)=>'<label class="field-label" for="p-'+id+'">'+label+'</label><textarea id="p-'+id+'" class="field" data-field="'+id+'" rows="'+rows+'">'+esc(value)+'</textarea>';
function workshop(){
const c=cases[route],live=row(),n=live.stage,r=n===4?(live.record||live):live,qq=r.lens?c.other:c.question;
const needsDraft=(n===2||n===3)&&!parts(r.draft).length;
let content='',ct='';
if(n===0){content='<h2>'+l('Read the brief','讀一讀題目')+'</h2><p>'+tr(c.brief)+'</p><h3>'+l('Case notes','案例材料')+'</h3><p class="note">'+tr(c.material)+'</p>';ct=l('Open my draft','打開草稿')}
if(n===1){content='<h2>'+l('Write a first draft','寫下初稿')+'</h2><p>'+tr(c.brief)+'</p><details class="choice-line"><summary>'+l('Read the case notes','重看案例材料')+'</summary><p class="note">'+tr(c.material)+'</p></details>'+field('draft',l('Your paragraph','你的段落'),r.draft,5)+btn(l('Use the sample draft','填入示例草稿'),'draft-example','micro choice-line');ct=l('Choose a sentence','選一句來檢查')}
if(n===2){content='<h2>'+l('Choose one sentence to work on','選一句值得修改的話')+'</h2><p>'+l('Select the sentence, then choose a question to guide your revision.','先點選原句，再選一個角度來思考如何修改。')+'</p><div class="sentences">'+parts(r.draft).map((x,i)=>btn(x.text,'line:'+i,'','aria-pressed="'+(i===r.index)+'"')).join('')+'</div><h3>'+l('What will you look at?','你想從哪個角度改寫？')+'</h3><div class="tabs">'+[c.focus,c.alternative].map((a,i)=>btn(tr(a),'lens:'+i,'','aria-pressed="'+(i===r.lens)+'"')).join('')+'</div><p class="note choice-line">'+tr(qq)+'</p>';ct=l('Revise this sentence','修改所選句子')}
if(n===3){const eligible=selected(r).text===tr(c.line);
content='<h2>'+l('Revise and explain','改寫，並說明理由')+'</h2><p>'+tr(qq)+'</p><h3>'+l('Selected sentence','你選的原句')+'</h3><p class="original">'+esc(selected(r).text)+'</p>'+field('fix',l('New wording','修改後的句子'),r.fix,2)+field('why',l('What did this change do for your reader?','這樣修改，對讀者有甚麼幫助？'),r.why,2)+(eligible?btn(l('Fill example revision and reason','填入示例改寫和理由'),'rev-example','micro choice-line'):'<details class="choice-line"><summary>'+l('See a worked example from the case','看看案例中的示範')+'</summary><p class="note">'+tr(c.line)+' → '+tr(r.lens?c.fix2:c.fix)+'</p></details>');ct=l('Save and compare','儲存並比較')}
if(needsDraft){content='<h2>'+l(n===2?'Review a sentence':'Revise a sentence',n===2?'檢查句子':'修訂句子')+'</h2><p>'+l('This step uses a sentence from your draft. Start with the case example here, or open Draft to write your own.','這一步會用到初稿中的句子。你可以在此載入案例，或按「起草」寫下自己的段落。')+'</p><div class="actions">'+btn(l('Use the sample draft','填入示例草稿'),'draft-example','primary-btn')+btn(l('Open Draft','前往起草'),'stage:1','minor')+'</div>'}
if(n===4){const x=selected(r);content='<h2>'+l('Your revision record','你的修訂記錄')+'</h2><div class="compare"><section><h3>'+l('First draft','原稿')+'</h3><p class="original">'+esc(r.draft)+'</p></section><section><h3>'+l('Revised draft','修訂稿')+'</h3><p class="note">'+esc(r.draft.slice(0,x.pos))+'<mark>'+esc(r.fix.trim())+'</mark>'+esc(r.draft.slice(x.pos+x.text.length))+'</p></section></div><h3>'+tr(r.lens?c.alternative:c.focus)+'</h3><p class="prose">'+esc(r.why)+'</p>'+(r.sample?'<p class="hint">'+l('This record used a worked example.','本次記錄使用了示例。')+'</p>':'');ct=l('Download writing record','下載寫作記錄')}
return nav()+'<main><div class="review-header">'+btn(l('← All writing tasks','← 返回任務選單'),'home','back')+'<p class="route-name">'+tr(levels[level])+' / '+tr(c.genre)+'</p><h1 class="school-title">'+tr(c.title)+'</h1><nav aria-label="'+l('Writing steps','寫作步驟')+'"><ol class="trail">'+(live.record||n===4?[...stages,['Record','記錄']]:stages).map((a,i)=>'<li>'+btn((i+1)+' · '+tr(a),'stage:'+i,'',i===n?'aria-current="step"':'')+'</li>').join('')+'</ol></nav></div><section class="sheet">'+content+'<p role="alert" id="p-warning" class="warning"></p><div class="actions">'+(n?btn(l('Back','上一步'),'back','minor'):'')+(needsDraft?'':(n<4?step(n+1):'')+btn(ct,n<4?'next':'export','primary-btn'))+(n===4?btn(l('Choose another task','選另一個任務'),'home','minor')+btn(l('Start this task again','重新開始這項練習'),'restart','minor'):'')+'</div><p class="saved-line">'+status()+'</p>'+(n>0&&n<4?btn(l('Restart this workshop','重新開始這項練習'),'restart','back choice-line'):'')+'</section></main>'}
function updateSchoolCue(){
 if(page!=='work')return;
 const r=row(),next=root.querySelector('[data-path="next"]');
 if(!next)return;
 const inline=next.previousElementSibling;
 const example=r.stage===1&&!r.draft.trim()?root.querySelector('[data-path="draft-example"]'):r.stage===3&&(!r.fix.trim()||!r.why.trim())?root.querySelector('[data-path="rev-example"]'):null;
 if(inline?.classList.contains('step-tag'))inline.hidden=!!example;
 root.querySelectorAll('.sample-target').forEach(el=>{el.classList.remove('sample-target');el.removeAttribute('data-cue')});
 if(example){example.classList.add('sample-target');example.dataset.cue=l('→ Step ','→ 步驟 ')+(r.stage+1)}
}
function redraw(scroll=false,focusKey=''){document.body.classList.toggle('path-mode',page!=='academic');if(page==='academic'){root.innerHTML='';window.apAcademic?.enter(lang?'zh':'en');return}document.documentElement.lang=lang?'zh-Hant':'en';root.innerHTML=page==='home'?home():workshop();updateSchoolCue();if(focusKey)root.querySelector('[data-path="'+focusKey+'"]')?.focus({preventScroll:true});if(scroll)window.scrollTo(0,0)}
function openPage(){const k=location.hash.slice(1);if(k==='main'&&page==='academic')return;if(k==='academic'){page='academic';level='university';route='research'}else if(Object.hasOwn(cases,k)){route=k;level=k==='primary'?'primary':'secondary';page='work'}else page='home';store();redraw(true)}
function go(k){const hash=k?'#'+k:'#tasks';if(location.hash===hash)openPage();else location.hash=hash}
window.apSetRouteLanguage=code=>{lang=code==='zh'?1:0;store()};
window.apHome=()=>{lang=document.documentElement.lang==='zh-Hant'?1:0;store();go('tasks')};
function makeRecord(r){return Object.fromEntries(['draft','index','lens','fix','why','sample'].map(k=>[k,r[k]]))}
function editKey(r){return JSON.stringify([selected(r).text,parts(r.draft).slice(0,r.index).filter(x=>x.text===selected(r).text).length,r.lens])}
function rememberEdit(r){if(!r.draft.trim())return;r.edits??={};r.edits[editKey(r)]=[r.fix,r.why]}
function restoreEdit(r){[r.fix,r.why]=r.edits?.[editKey(r)]||['','']}
function warn(txt,el){document.querySelector('#p-warning').textContent=txt;root.querySelector(el)?.focus()}
root.addEventListener('input',e=>{const k=e.target.dataset.field;if(!k)return;const r=row();if(k==='draft'&&r.draft!==e.target.value){const prev=selected(r).text;rememberEdit(r);r.draft=e.target.value;const list=parts(r.draft);if(list[r.index]?.text!==prev)r.index=Math.max(0,list.findIndex(x=>x.text===prev));restoreEdit(r);r.sample=false}else r[k]=e.target.value;store();updateSchoolCue()});
root.addEventListener('click',e=>{const b=e.target.closest('button[data-path]');if(!b)return;const [a,k]=b.dataset.path.split(':');
if(a==='home'){go('tasks');return}if(a==='language'){
 const nextLanguage=Number(k)===1?1:0;
 if(lang===nextLanguage)return;
 const old=page==='work'?row():null;
 lang=nextLanguage;
 if(old){
  const target=row();
  if(target.stage===4&&!target.record)target.record=makeRecord(target);
  if(!hasWork(old))freshRun();
  else target.stage=old.stage===4?(target.record?4:0):old.stage>=2&&!parts(target.draft).length?0:old.stage;
 }
 store();redraw(false,'language:'+lang);return
}if(a==='level'||a==='genre'){if(a==='level'){level=k;route=tracks[k][0]}else route=k;store();redraw(false,b.dataset.path);return}if(a==='start'||a==='resume'||a==='oldrun'){
 if(route==='research'){if(a==='start')window.apAcademic?.begin?.();go('academic');return}
 if(a==='start')freshRun();
 else if(a==='oldrun')restoreRun(Number(k));
 else if(!hasWork(row())&&pastRuns().length)restoreRun(0);
 store();go(route);return
}
const r=row(),c=cases[route];if(!c)return;
if(r.stage===4&&!r.record)r.record=makeRecord(r);
if(a==='stage'){const destination=Number(k);if(Number.isInteger(destination)&&destination>=0&&destination<=(r.record?4:3)){r.stage=destination;store();redraw(true,b.dataset.path)}return}
if(a==='restart'){if(!confirm(r.stage===4?l('Start a fresh draft for this task and language? Download the current record first if you want to keep it.','要重新開始這項練習嗎？如要保留本次記錄，請先下載。'):l('Clear this unfinished draft and start again?','清除這份未完成的草稿，重新開始嗎？')))return;delete saved.work[route+'-'+lang];store();redraw(true);return}
if(a==='draft-example'){if(r.draft.trim()&&r.draft!==tr(c.draft)&&!confirm(l('Replace this draft with the sample?','以示例取代目前草稿？')))return;if(r.draft===tr(c.draft)){store();redraw(false);return}rememberEdit(r);r.draft=tr(c.draft);r.index=Math.max(0,parts(r.draft).findIndex(x=>x.text===tr(c.line)));restoreEdit(r);r.sample=true}
if(a==='line'||a==='lens'){const prop=a==='line'?'index':'lens';if(r[prop]!==Number(k)){rememberEdit(r);r[prop]=Number(k);restoreEdit(r)}}
if(a==='rev-example'){if((r.fix.trim()||r.why.trim())&&!confirm(l('Replace the revision and reason with the example?','以示例取代目前的改寫和理由？')))return;r.fix=tr(r.lens?c.fix2:c.fix);r.why=tr(r.lens?c.why2:c.why);r.sample=true}
if(a==='next'){if(r.stage===1&&!parts(r.draft).length){warn(l('Write a sentence or load the sample draft.','請先寫下一句，或填入示例草稿。'),'#p-draft');return}if(r.stage===3){if(!r.fix.trim()||r.fix.trim()===selected(r).text){warn(l('Change the selected sentence before saving.','請先改寫所選的句子。'),'#p-fix');return}if(!r.why.trim()){warn(l('Add a reason for the change.','請說明修改的理由。'),'#p-why');return}r.record=makeRecord(r)}r.stage++}
if(a==='back')r.stage=Math.max(0,r.stage-1);
if(a==='export'){const r=row().record||row();const record=[tr(c.title),tr(c.genre),l('First draft','原稿'),r.draft,l('Revised draft','修訂稿'),revised(r),tr(r.lens?c.alternative:c.focus),r.why,r.sample?l('Worked example used','本記錄使用示例'):''].filter(Boolean).join('\n\n');const url=URL.createObjectURL(new Blob([record],{type:'text/plain;charset=utf-8'}));const link=document.createElement('a');link.href=url;link.download='ArguPath-'+route+'.txt';link.click();setTimeout(()=>URL.revokeObjectURL(url),1500);return}
store();redraw(a==='next'||a==='back',a==='next'||a==='back'?'':b.dataset.path)
});
window.addEventListener('hashchange',openPage);openPage();
})();
