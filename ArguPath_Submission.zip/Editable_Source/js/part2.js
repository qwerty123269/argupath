/* script_02.js */

(function(root,factory){if(typeof module==='object')module.exports=factory();else root.APFlow=factory();})(typeof globalThis!=='undefined'?globalThis:this,function(){
'use strict';
const copy=x=>JSON.parse(JSON.stringify(x));
function create(C,kind='practice'){const p=C.seed(kind);p.draft=kind==='personal'?p.draft:[];p.sources=[];p.claims=[];p.comments=[];p.decisions={};p.flow={loaded:kind==='personal',confirmed:false,generated:[],runs:[],revision:0,trajectory:copy(C.trajectory)};return p;}
function invalidate(p,reason){if(!p.flow)return;p.flow.revision++;p.flow.changed=reason;if(p.flow.run)p.flow.run.outdated=true;if(reason==='materials'||reason==='data')p.flow.generated=p.flow.generated.filter(x=>x!=='effects'&&x!=='change');}
function load(C,p){if(p.flow.loaded)return;p.draft=copy(C.draft);p.flow.loaded=true;p.flow.baseline=copy(p.draft);invalidate(p,'draft');}
function confirm(C,p,ids){if(!Array.isArray(ids)||!ids.length)throw Error('MATERIALS_REQUIRED');const existing=p.sources;p.sources=ids.map(id=>existing.find(s=>s.id===id)||C.studies.find(s=>s.id===id)).filter(Boolean).map(copy);if(!p.sources.length)throw Error('MATERIALS_REQUIRED');p.flow.confirmed=true;for(const c of p.claims){for(const sid of Object.keys(c.relations))if(!ids.includes(sid)){delete c.relations[sid];if(c.reasons)delete c.reasons[sid];}}invalidate(p,'materials');}
function analyse(C,p){if(!p.draft.some(x=>x.text.trim()))throw Error('DRAFT_REQUIRED');if(!p.flow.confirmed||!p.sources.length)throw Error('MATERIALS_REQUIRED');if(p.kind==='personal')throw Error('MANUAL_ONLY');if(p.flow.run&&!p.flow.run.outdated)return p.flow.run;
if(p.flow.run)p.flow.runs.push({run:copy(p.flow.run),comments:copy(p.comments),decisions:copy(p.decisions),hints:copy(p.hints)});
const missing=[],unmatched=[],dataChanged=[],eligible=[];
for(const f of C.feedback){if(!p.draft[f.p]?.text.includes(f.quote)){unmatched.push(f.id);continue;}const absent=f.sources.filter(id=>!p.sources.some(s=>s.id===id));if(absent.length){missing.push({id:f.id,sources:absent});continue;}if(f.sources.some(id=>p.sources.find(s=>s.id===id)?.editedData)){dataChanged.push(f.id);continue;}eligible.push(copy(f));}
p.comments=eligible;p.decisions={};p.decisionDrafts={};p.hints={};const run={id:'R'+(p.flow.runs.length+1),at:new Date().toISOString(),revision:p.flow.revision,paragraphs:copy(p.draft),sources:copy(p.sources),missing,unmatched,dataChanged,ids:eligible.map(f=>f.id),outdated:false};p.flow.run=run;return run;}
function editEstimate(p,id,values,reason){const s=p.sources.find(s=>s.id===id);if(!s||s.effect===undefined||values.some(x=>!Number.isFinite(x))||values[1]>values[0]||values[0]>values[2]||!reason.trim())throw Error('INVALID_ESTIMATE');[s.effect,s.lo,s.hi]=values;s.result=`MD = ${s.effect} [${s.lo}, ${s.hi}]`;s.editedData=true;s.dataReason=reason.trim();invalidate(p,'data');}
function generate(C,p,kind){if(!['effects','change','coverage','process'].includes(kind))throw Error('UNKNOWN_CHART');if(kind==='effects'&&(!p.flow.confirmed||!p.sources.some(s=>s.effect!==undefined)))throw Error('CONFIRM_TRIAL');if(kind==='change'&&(!p.flow.confirmed||!p.sources.some(s=>s.id==='S3')))throw Error('NEED_S3');if(kind==='coverage'&&!p.claims.length)throw Error('CLAIM_REQUIRED');if(kind==='process'&&!Object.keys(p.decisions).length&&!p.versions.length)throw Error('RECORD_REQUIRED');if(!p.flow.generated.includes(kind))p.flow.generated.push(kind);}
function mapExample(C,p){if(!p.flow.run||p.flow.run.outdated)throw Error('ANALYSIS_REQUIRED');p.claims=copy(C.claims.filter(c=>p.draft[c.paragraph]?.text===C.draft[c.paragraph]?.text));for(const c of p.claims){for(const sid of Object.keys(c.relations))if(!p.sources.some(s=>s.id===sid)){delete c.relations[sid];delete c.reasons[sid];}}return p.claims;}
function validate(p){if(!p.flow)return p;const f=p.flow;if(!Array.isArray(f.generated)||f.generated.some(x=>!['effects','change','coverage','process'].includes(x))||!Array.isArray(f.runs)||!Number.isFinite(f.revision)||typeof f.loaded!=='boolean'||typeof f.confirmed!=='boolean')throw Error('INVALID_FLOW');return p;}
return {create,invalidate,load,confirm,analyse,editEstimate,generate,mapExample,validate};
});


