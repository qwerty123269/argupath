ArguPath | INT6065 · Group 13
网页入口：解压后，双击最外层的 index.html。所有样式、脚本及案例都在这个文件内。网页默认以英语打开，右上角同时显示 English 和繁體中文，点选即可切换。学段由使用者自行选择，无需提供姓名或出生日期。

首页依次选择学段、文体，再按 Start from Step 1，从空白练习的读题页开始。要回到原来位置，点 Resume。过往练习按案例和语言分开保存。「读题、起草、检查、修订」均可直接点选。在检查或修订页尚无草稿时，可就地载入示例。保存后，第五个「记录」按钮可回看上次保存的原稿、改写及理由。首页下方三张说明卡可展开，展示当前文体的任务、检查问题和记录用途。每种文体、每种语言有独立记录，切换语言可回到该语言上次的位置。共用电脑演示请使用示例材料。

文件用途
• index.html：可直接双击，也可上传到 GitHub Pages 的完整网页。
• Editable_Source/：与单文件版等价的可编辑源码。修改这一版时须连同 css、js 两个目录一起保留。css/part3.css 与 js/part4.js 对应新增学段界面、案例和操作流程。
• Presentation/：20 页可编辑 PPT 和按六个板块整理的双语讲者备注。第 18 页内嵌原有大学案例视频，时长 2 分 55 秒。
• School_Demo/：展示新入口与中小学功能的 2 分钟录制说明和英文字幕。和 PPT 第 8、15 页配合使用。
• University_Demo/：已录制学术写作辅导（主要 Demo 展示板块）的原版操作指南、截图、字幕和旁白；新版从 University → Academic writing → Start academic demo · Step 1 进入这段流程。网页里的 All steps 可以点选 16 个步骤、前后翻阅说明，并打开对应工作区。
• AI_use_EN_ZH.txt：本项目 AI 使用范围。

更新原网址
GitHub Pages 仓库 qwerty123269/argupath 使用 main 分支根目录。上传本包最外层的 index.html，覆盖仓库中同名文件并提交。待 Pages 部署成功后，用无痕窗口打开 https://qwerty123269.github.io/argupath/ 。出现 Choose a writing task 及三个学段即为新版。只需发布这个公开网页文件。课件、组员资料和讲稿保存在交付包中。

设计参考
ReadWriteThink 的 Story Map 按叙事要素组织问题；Persuasion Map 将主张、理由和支撑材料组织起来。本项目据此选择适合文体的检查问题，自编题目、材料与示例。
https://www.readwritethink.org/classroom-resources/student-interactives/story
https://www.readwritethink.org/classroom-resources/student-interactives/persuasion
